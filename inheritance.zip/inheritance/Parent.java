package com.inheritance;

public class Parent {
    
	public void m1()
	{
		System.out.println("i a m1 parent class m1 method");
	}
	public void m2()
	{
		System.out.println("i a m2 parent class m2 method");
	}
	public void m3()
	{
		System.out.println("i a m3 parent class m3 method");
	}
}
