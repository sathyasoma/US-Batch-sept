package com.two;
// create a program that generates random numbers using the random() method.

public class RandomEx {
	public static void main(String args[]) {
		// Generating random numbers
		System.out.println("1st Random Number: " + Math.random());
		System.out.println("2nd Random Number: " + Math.random());
		System.out.println("3rd Random Number: " + Math.random());
		System.out.println("4th Random Number: " + Math.random());
	}
}
