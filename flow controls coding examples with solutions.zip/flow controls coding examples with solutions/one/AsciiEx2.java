package com.one;
//write a java program convert charecter values to ascii value
public class AsciiEx2 {

	public static void main(String[] String)   
	{  
	int ch1 = 'a';  
	int ch2 = 'b';  
	System.out.println("The ASCII value of a is: "+ch1);  
	System.out.println("The ASCII value of b is: "+ch2);  
	}  
}
