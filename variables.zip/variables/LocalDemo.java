package com.variables;

public class LocalDemo {

	
	public static void main(String[] args) {
		
		int age=89; //local variables
		String name="keerthi";
		System.out.println("my age is "+age);
		System.out.println("my name is :"+name);
	}
}
