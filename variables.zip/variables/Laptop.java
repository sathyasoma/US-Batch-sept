package com.variables;

public class Laptop {
     //static varaibales 
	static int keys=67;
	static String screen="LED";
	
	public static void main(String[] args) {
		
		
		System.out.println("LAPTOP KEYS ARE :"+Laptop.keys);
		System.out.println("LAPTOP SCREEN IS :"+Laptop.screen);
	}
}
