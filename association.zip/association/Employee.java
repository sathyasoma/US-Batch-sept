package com.association;

public class Employee  {

	String name;
	int slary;
	Adress add;
}
