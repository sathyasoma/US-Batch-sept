package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("sathya");
		EntityManager entity=factory.createEntityManager();
		
		//insert-persist(),update--merge() ,delete-remove(),fetch-find()
		
	Employee emp= new Employee("rahul", 3733, "ohio", 23);
	
	entity.getTransaction().begin();
		//entity.persist(emp);
		
	Employee emp1=entity.find(Employee.class, 1);
		
	System.out.println(emp1.getEmpname()+" "+emp1.getEmpsal());
		
	emp1.setEmpadd("hyd");
	emp1.setEmpname("keerthi");
	emp1.setEmpsal(6666);
	
	//entity.merge(emp1);
	entity.remove(emp1);	
		
		entity.getTransaction().commit();
		
		
	}
}
