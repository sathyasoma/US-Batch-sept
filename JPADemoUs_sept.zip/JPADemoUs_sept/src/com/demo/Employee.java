package com.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity //table createion in db
@Table(name="karthik")
public class Employee {

	@Id//primary key generation in table
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id",length = 10)
	private int empid;
	@Column(name="name",length = 20,nullable = false,unique=true)
	private String empname;
	private int empsal;
	private String empadd;
	@Transient //not column in db
	private int age;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getEmpsal() {
		return empsal;
	}
	public void setEmpsal(int empsal) {
		this.empsal = empsal;
	}
	public String getEmpadd() {
		return empadd;
	}
	public void setEmpadd(String empadd) {
		this.empadd = empadd;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(String empname, int empsal, String empadd, int age) {
		super();
	
		this.empname = empname;
		this.empsal = empsal;
		this.empadd = empadd;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", empsal=" + empsal + ", empadd=" + empadd
				+ ", age=" + age + "]";
	}
	
	
	
}
