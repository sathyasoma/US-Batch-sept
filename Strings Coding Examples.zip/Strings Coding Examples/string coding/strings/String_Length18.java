package com.strings;
//Write a program to get the length of a given string

public class String_Length18 {
	public static void main(String[] args)
	{  
		String str = "Java Exercise";
		int len = str.length();
		System.out.println("Given String : "+str);
		System.out.println("String Length : "+len);
	}
}
