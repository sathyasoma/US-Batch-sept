package acom.abstraction;

public class Hacker {

	public static void main(String[] args) {
				
		//Electronic ele= new Electronic();//we cant cretae object
		
		
	}
}
