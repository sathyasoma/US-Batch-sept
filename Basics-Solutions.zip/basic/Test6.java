package com.basic;

import java.util.Scanner;

public class Test6 {
	public static void main(String args[])
	 {
	 Scanner s=new Scanner(System.in);
	 int a=s.nextInt();
	 System.out.print((char)a);
	 }
}
