package com.basic;

import java.util.Scanner;

public class Test7 {
	public static void main(String args[])
	 {
	 Scanner s=new Scanner(System.in);
	 char a=s.next().charAt(0);
	 System.out.print((int)a);
	 }
}
