package com.basic;

import java.util.Scanner;

public class Test2 {
	public static void main(String args[])
	 {
	 Scanner s=new Scanner(System.in);
	 int n=s.nextInt();
	 System.out.print(n);
	 }
}
