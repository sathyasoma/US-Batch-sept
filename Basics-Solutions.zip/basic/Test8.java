package com.basic;

import java.util.Scanner;

public class Test8 {

	public static void main(String [] args) {
		String name;
		Scanner sc= new Scanner(System.in);
		name = sc.nextLine();
		System.out.println("Hello "+name+ " ! Welcome to Examly Event Management System");
		}
}
