package com.basic;

import java.util.Scanner;

public class Test9 {
	public static void main(String args[]){
		 int x,y;
		 double z;
		 Scanner sc=new Scanner(System.in);
		 x=sc.nextInt();
		 y=sc.nextInt();
		 z=x+y;
		 System.out.println(z);
		 }
}
