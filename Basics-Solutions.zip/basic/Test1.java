package com.basic;

import java.util.Scanner;

public class Test1 {
	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
		 String N;
		 N=sc.nextLine();
		 String m;
		 m=sc.nextLine();
		 System.out.println(N +" and "+ m);
		 }
}
