package com.basic;

import java.util.Scanner;

public class Test3 {
	public static void main(String args[])
	 {
	 Scanner s=new Scanner(System.in);
	 float n=s.nextFloat();
	 System.out.printf("%.3f\n",n);
	 System.out.printf("%.2f\n",n);
	 System.out.printf("%.1f\n",n);
	 }
}
