package com.basic;

import java.util.Scanner;

public class Test10 {
	public static void main(String[] args) 
	 {
	 Scanner s = new Scanner(System.in);
	int n1 = s.nextInt();
	double n2 = s.nextDouble();
	boolean n3 = s.nextBoolean();
	s.nextLine();
	char c = s.nextLine().charAt(0);
	String n4 = s.nextLine();
	System.out.println("Integer value = " + n1 + "\nDouble value = " + n2 + "\nBoolean value = " + n3 + "\nchar value = " + c + "\nString value = " + n4);
	}

}
