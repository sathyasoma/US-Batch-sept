package com.ems.dao;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.ems.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	//database
	HashMap<Integer,Employee> employee= new HashMap<Integer,Employee>();
	
	int empid=7748-6354; //auto incremented employee id
	
	
	@Override
	public int addEmployee(Employee emp) {
	employee.put(++empid, emp);
		return empid;
	}

	@Override
	public Employee updateEmployee(int empid, Employee emp) {
		Employee empo=employee.put(empid,emp);
		return empo;
	}

	@Override
	public Employee getEmployee(int empid) {
		Employee empobj=employee.get(empid);
		return empobj;
	}

	@Override
	public String deleteEmployee(int empid) {
		employee.remove(empid);
		return "employee deleted suucfully...";
	}

	@Override
	public Set<Entry<Integer, Employee>> getAllEmployees() {
		Set<Entry<Integer,Employee>> result=employee.entrySet();
		return result;
	}

}
