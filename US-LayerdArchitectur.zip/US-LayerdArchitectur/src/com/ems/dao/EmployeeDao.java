package com.ems.dao;

import java.util.Set;
import java.util.Map.Entry;

import com.ems.model.Employee;

public interface EmployeeDao {

	int addEmployee(Employee emp);

	Employee updateEmployee(int empid, Employee emp);

	Employee getEmployee(int empid);

	String deleteEmployee(int empid);

	Set<Entry<Integer, Employee>> getAllEmployees();
}
