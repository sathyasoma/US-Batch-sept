package com.ems.presentation;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.ems.exceptions.EmployeeNotFoundException;
import com.ems.exceptions.InputMissMatchException;
import com.ems.model.Employee;
import com.ems.service.EmployeeService;
import com.ems.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) throws InputMissMatchException, EmployeeNotFoundException {
		// to get the data from service layer we can create object of service layer
		EmployeeService service = new EmployeeServiceImpl();

		Scanner sc = new Scanner(System.in);

		while (true) {
			try {
				System.out.println("*****Employee MANAGEMENT aPPLICATION****");
				System.out.println("1.Add Employee");
				System.out.println("2.Update Employee");
				System.out.println("3.Get Employee");
				System.out.println("4.Delete Employee");
				System.out.println("5.Get All Employees");
				System.out.println("6.Exit");

				int option = sc.nextInt();

				switch (option) {
				case 1:
					try {
						System.out.println("***Employee Detailes***");
						System.out.println("Enter Employee Name");
						String empName = sc.next();
						System.out.println("Enter EMployee Salary");
						int empSal = sc.nextInt();
						if (empSal <= 0) {
							throw new InputMissMatchException("Employee Slary must be positive");
						}
						System.out.println("Enter Employee Address");
						String empAdd = sc.next();
						System.out.println("Enter Employee Mail id");
						String empMail = sc.next();

						// object of employee
						Employee emp = new Employee(empName, empSal, empAdd, empMail);

						int empid = service.addEmployee(emp);
						System.out.println("Employee addded succfully :" + empid);
					} catch (InputMissMatchException iie) {
						System.out.println(iie.getMessage());
					} catch (Exception ae) {
						System.out.println("Error in adding Employee :" + ae.getMessage());
					}

					break;
				case 2:
					try {
						System.out.println("Enter EMployee Id");
						int eid = sc.nextInt();
						System.out.println("Enter Employee Name");
						String empname = sc.next();
						System.out.println("Enter EMployee Salary");
						int empsal = sc.nextInt();
						if (empsal <= 0) {
							throw new InputMissMatchException("Employee Slary must be positive");
						}
						System.out.println("Enter Employee Address");
						String empadd = sc.next();
						System.out.println("Enter Employee Mail id");
						String empmail = sc.next();

						Employee emp1 = new Employee(empname, empsal, empadd, empmail);

						Employee updateEmp = service.updateEmployee(eid, emp1);

						if (updateEmp != null) {
							System.out.println("Employee added suufully :" + updateEmp);
						} else {
							throw new EmployeeNotFoundException("Employee not found with id :" + eid);
						}
					} catch (InputMissMatchException | EmployeeNotFoundException e) {
						System.out.println(e.getMessage());
					} catch (Exception e) {
						System.out.println("error handling in update employee");
					}
					break;
				case 3:
					try {
						System.out.println("Enter Employee Id");
						int eid1 = sc.nextInt();
						Employee empobj = service.getEmployee(eid1);
						if (empobj != null) {
							System.out.println(empobj);
						} else {
							throw new EmployeeNotFoundException("Employee not found id :" + eid1);
						}
					} catch (EmployeeNotFoundException e) {
						System.out.println(e.getMessage());
					} catch (Exception e) {
						System.out.println("Error handling in get employee :" + e.getMessage());
					}
					break;
				case 4:
					try {
						System.out.println("Enter Employee Id");
						int eid2 = sc.nextInt();
						String res = service.deleteEmployee(eid2);
						if (res != null) {
							System.out.println(res);
						} else {
							throw new EmployeeNotFoundException("Employee not found id :" + eid2);
						}
					} catch (EmployeeNotFoundException e) {
						System.out.println(e.getMessage());
					} catch (Exception e) {
						System.out.println("Error handling in get employee :" + e.getMessage());
					}
					break;
				case 5:
					try {
						Set<Entry<Integer, Employee>> result = service.getAllEmployees();

						if (result.isEmpty()) {
							System.out.println("no employees found");
						} else {
							Iterator<Entry<Integer, Employee>> itr = result.iterator();
							while (itr.hasNext()) {
								Entry<Integer, Employee> finalResult = itr.next();
								System.out.println(finalResult.getKey() + " " + finalResult.getValue());
							}
						}
					} catch (Exception e) {
						System.out.println("handling get all employees :" + e.getMessage());
					}
					break;
				case 6:
					System.out.println("Exiting Application.......");
					sc.close();
					System.exit(0);
					break;
				default:
					throw new InputMissMatchException("invalid data enetrd ");

				}
			} catch (InputMissMatchException e) {
				System.out.println("invalid data enetrd");
			} catch (Exception e) {
				System.out.println("EXCeption handled");
			}
		}
	}
}
