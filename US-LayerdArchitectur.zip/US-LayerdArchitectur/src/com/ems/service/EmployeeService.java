package com.ems.service;

import java.util.Map.Entry;
import java.util.Set;

import com.ems.model.Employee;

public interface EmployeeService {

	// only abstarct methods

	int addEmployee(Employee emp);

	Employee updateEmployee(int empid, Employee emp);

	Employee getEmployee(int empid);

	String deleteEmployee(int empid);

	Set<Entry<Integer, Employee>> getAllEmployees();
}
