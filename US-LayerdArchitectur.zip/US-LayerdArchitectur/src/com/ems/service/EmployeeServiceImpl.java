package com.ems.service;

import java.util.Map.Entry;
import java.util.Set;

import com.ems.dao.EmployeeDao;
import com.ems.dao.EmployeeDaoImpl;
import com.ems.model.Employee;

public class EmployeeServiceImpl implements EmployeeService{

	//create object of dao layer to access all the methods
	
	EmployeeDao dao= new EmployeeDaoImpl();
	
	@Override
	public int addEmployee(Employee emp) {
		
		return dao.addEmployee(emp);
	}

	@Override
	public Employee updateEmployee(int empid, Employee emp) {
		
		return dao.updateEmployee(empid, emp);
	}

	@Override
	public Employee getEmployee(int empid) {
		
		return dao.getEmployee(empid);
	}

	@Override
	public String deleteEmployee(int empid) {
		
		return dao.deleteEmployee(empid);
	}

	@Override
	public Set<Entry<Integer, Employee>> getAllEmployees() {
	
		return dao.getAllEmployees();
	}

}
