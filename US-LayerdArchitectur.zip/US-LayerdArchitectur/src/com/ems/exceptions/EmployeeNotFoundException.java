package com.ems.exceptions;

public class EmployeeNotFoundException extends Exception{

	public EmployeeNotFoundException(String message) {
		super(message);
	}
}

//our class should be exetends with super 
//our class a=has atlesast one peram consctrutor