package com.ems.exceptions;

public class InputMissMatchException extends Exception {

	public InputMissMatchException(String message) {
		super(message);
	}
}
