package com.demo.controller;

import com.demo.exception.EmployeeNotFoundException;
import com.demo.model.Employee;
import com.demo.service.EmployeeService;
import com.demo.service.EmployeeServiceImpl;

public class Client {
public static void main(String[] args) {
	
	EmployeeService service= new EmployeeServiceImpl();
	
	try {
		
		Employee emp= new Employee(100, "karthik", 8973, "ohio");
		//service.addEmployee(emp);
		
		//fecthing the data from database
		Employee emp1=service.findEmployeeById(100);
		System.out.println(emp1);
		
		//updating dtaa from databse
		emp1.setEmpadd("hyd");
		emp1.setEmpname("sathya");
		emp1.setEmpsal(70000);
		
		//service.updateEmployee(emp1);
		//service.deleteEmployee(emp1);
	}
	catch (EmployeeNotFoundException e) {
		System.err.println("Error :"+e.getMessage());
	}catch (Exception e) {
		System.err.println("An Unexpected Exception :"+e.getMessage());
	}
}
}
