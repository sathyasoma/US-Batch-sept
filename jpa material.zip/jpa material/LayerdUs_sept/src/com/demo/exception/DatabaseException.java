package com.demo.exception;

public class DatabaseException extends RuntimeException{

	public DatabaseException(String message) {
		 super(message);
	}
}
