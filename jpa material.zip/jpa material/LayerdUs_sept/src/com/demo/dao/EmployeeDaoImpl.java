package com.demo.dao;

import javax.persistence.EntityManager;

import com.demo.exception.DatabaseException;
import com.demo.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	
	//object of createing entity
	private EntityManager entity;
	
  //default construtor daoimpl
	public EmployeeDaoImpl() {
		entity=JPAUtil.getEntityManager();
	}
	
	@Override
	public Employee getEmployeeBYId(int empid) {
		try {
		Employee emp=entity.find(Employee.class, empid);
	if(emp==null)
	{
		throw new DatabaseException("Employee not found with id :"+empid);
	}
		return emp;
		}
		catch (Exception e) {
			throw new DatabaseException("Error with fetching employee id"+e);
		}
	}

	@Override
	public void addEmployee(Employee emp) {
		try {
			entity.persist(emp);
		}catch (Exception e) {
			throw new DatabaseException("Error with addibg employee id"+e);
		}
		
	}

	@Override
	public void updateEmployee(Employee emp) {
		try {
			entity.merge(emp);
		}catch (Exception e) {
			throw new DatabaseException("Error with updating employee id"+e);
		}
		
	}

	@Override
	public void deleteEmployee(Employee emp) {
		try {
			entity.remove(emp);
		}catch (Exception e) {
			throw new DatabaseException("Error with deleteing employee id"+e);
		}
		
	}

	@Override
	public void beginTrascation() {
		entity.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entity.getTransaction().commit();
		
	}

	@Override
	public EntityManager getEntityManager() {
	
		return entity;
	}

}
