package com.demo.dao;

import javax.persistence.EntityManager;

import com.demo.model.Employee;

public interface EmployeeDao  {

	Employee getEmployeeBYId(int empid);

	void addEmployee(Employee emp);

	void updateEmployee(Employee emp);

	void deleteEmployee(Employee emp);

	void beginTrascation();

	void commitTransaction();
	
	EntityManager getEntityManager();

}
