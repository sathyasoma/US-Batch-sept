package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	 public static void main(String[] args) {
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("examplePU");
	        EntityManager em = emf.createEntityManager();

	        em.getTransaction().begin();

	        Profile profile = new Profile();
	        em.persist(profile);

	        Account account = new Account();
	        account.setProfile(profile);
	        profile.setAccount(account);
	        em.persist(account);

	        em.getTransaction().commit();

	        // Fetch
	        Profile fetchedProfile = em.find(Profile.class, profile.getId());
	        System.out.println("Fetched Profile with Account ID: " + fetchedProfile.getAccount().getId());

	        // Update
	        em.getTransaction().begin();
	        fetchedProfile.getAccount().setProfile(null);
	        em.getTransaction().commit();

	        // Delete
	        em.getTransaction().begin();
	        em.remove(fetchedProfile);
	        em.getTransaction().commit();

	        em.close();
	        emf.close();
	    }
}
