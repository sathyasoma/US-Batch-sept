package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	 public static void main(String[] args) {
		
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("keerthi");
	        EntityManager em = emf.createEntityManager();

	        em.getTransaction().begin();

	        Customer customer = new Customer();
	        customer.setName("John Doe");
	        em.persist(customer);

	        Order order = new Order();
	        order.setCustomer(customer);
	        em.persist(order);

	        em.getTransaction().commit();

	        Order fetchedOrder = em.find(Order.class, order.getId());
	        System.out.println("Fetched Order with Customer: " + fetchedOrder.getCustomer().getName());

	        em.close();
	        emf.close();
		    }
}
