package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	 public static void main(String[] args) {
		
		    EntityManagerFactory emf = Persistence.createEntityManagerFactory("examplePU");
	        EntityManager em = emf.createEntityManager();

	        em.getTransaction().begin();

	        Course course1 = new Course();
	        course1.setTitle("Math");
	        Course course2 = new Course();
	        course2.setTitle("Science");

	        Student student = new Student();
	        student.getCourses().add(course1);
	        student.getCourses().add(course2);
	        em.persist(student);

	        em.getTransaction().commit();

	        Student fetchedStudent = em.find(Student.class, student.getId());
	        System.out.println("Fetched Student with Courses: ");
	        fetchedStudent.getCourses().forEach(course -> System.out.println(course.getTitle()));

	        em.close();
	        emf.close();
		    }
}
