package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	 public static void main(String[] args) {
		
		        EntityManagerFactory emf = Persistence.createEntityManagerFactory("keerthi");
		        EntityManager em = emf.createEntityManager();

		        em.getTransaction().begin();

		        Author author = new Author();
		        em.persist(author);

		        Book book1 = new Book();
		        book1.getAuthors().add(author);
		        em.persist(book1);

		        Book book2 = new Book();
		        book2.getAuthors().add(author);
		        em.persist(book2);

		        em.getTransaction().commit();

		        Author fetchedAuthor = em.find(Author.class, author.getId());
		        System.out.println("Fetched Author with Books: ");
		        fetchedAuthor.getBooks().forEach(book -> System.out.println("Book ID: " + book.getId()));

		        em.close();
		        emf.close();
		    }
}
