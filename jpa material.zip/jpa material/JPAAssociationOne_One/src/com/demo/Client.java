package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("keerthi");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();

        Person person = new Person();
        person.setName("Eve");
        //em.persist(person);

        Passport passport = new Passport();
        passport.setPerson(person);
     //   em.persist(passport);

        em.getTransaction().commit();

        // Fetch
        if (em.isOpen()) {
            Passport fetchedPassport = em.find(Passport.class, passport.getId());
            System.out.println("Fetched Passport: " + fetchedPassport);
        } else {
            System.out.println("EntityManager is closed!");
        }

        // Update
        em.getTransaction().begin();
        //fetchedPassport.getPerson().setName("Updated Eve");
        em.getTransaction().commit();

        // Delete
        em.getTransaction().begin();
        //em.remove(fetchedPassport);
        em.getTransaction().commit();

        em.close();
        emf.close();

		
	}
}
