package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	 public static void main(String[] args) {
		
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("keerthi");
	        EntityManager em = emf.createEntityManager();

	        em.getTransaction().begin();

	        User user = new User();
	        em.persist(user);

	        Post post1 = new Post();
	        post1.setUser(user);
	        em.persist(post1);

	        Post post2 = new Post();
	        post2.setUser(user);
	        em.persist(post2);

	        em.getTransaction().commit();

	        User fetchedUser = em.find(User.class, user.getId());
	        System.out.println("Fetched User with Posts: ");
	        fetchedUser.getPosts().forEach(post -> System.out.println("Post ID: " + post.getId()));

	        em.close();
	        emf.close();
		    }
}
