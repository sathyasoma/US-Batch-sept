package com.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("keerthi");
		EntityManager entity = factory.createEntityManager();
		entity.getTransaction().begin();

		// Inserting data
		Employee e = new Employee(123, "Sathya", 4000, "hyd");
		Employee e1 = new Employee(124, "prakash", 9000, "nlg");
		Employee e2 = new Employee(125, "keerthi", 2000, "goa");
		Employee e3 = new Employee(126, "Divya", 8000, "knl");

		entity.persist(e);
		entity.persist(e1);
		entity.persist(e2);
		entity.persist(e3);

		// Fetching capitalized names
		Query capQuery = entity.createNamedQuery("Employee.getAllNamesUpperCase");
		List<String> names = capQuery.getResultList();
		names.forEach(name -> System.out.println("Employee Name: " + name));

		// Fetching maximum salary
		Query maxSalQuery = entity.createNamedQuery("Employee.getMaxSalary");
		int maxSalary = (int) maxSalQuery.getSingleResult();
		System.out.println("Maximum Salary: " + maxSalary);

		// Fetching employees within salary range
		Query salaryRangeQuery = entity.createNamedQuery("Employee.getEmployeesWithinSalaryRange")
				.setParameter("minSalary", 2000).setParameter("maxSalary", 90000);
		List<Employee> employeesInRange = salaryRangeQuery.getResultList();
		employeesInRange.forEach(emp -> System.out.println("Employee: " + emp));

		// Fetching employees with names like 'S%'
		Query likeQuery = entity.createNamedQuery("Employee.getEmployeesWithNameLike")
				.setParameter("pattern", "S%");
		List<Employee> employeesLike = likeQuery.getResultList();
		employeesLike.forEach(emp -> System.out.println("Employee: " + emp));

		// Fetching all employees
		Query allEmployeesQuery = entity.createNamedQuery("Employee.getAllEmployees");
		List<Employee> allEmployees = allEmployeesQuery.getResultList();
		allEmployees.forEach(emp -> System.out.println("Employee: " + emp));

		// Updating salaries
		Query updateQuery = entity.createNamedQuery("Employee.updateEmployeeSalaries")
				.setParameter("increment", 5000)
				.setParameter("threshold", 9000);
		int updatedRecords = updateQuery.executeUpdate();
		System.out.println("Updated Records: " + updatedRecords);

		// Ordering employees by name
		Query orderQuery = entity.createNamedQuery("Employee.orderEmployeesByName");
		List<Employee> orderedEmployees = orderQuery.getResultList();
		orderedEmployees.forEach(emp -> System.out.println("Ordered Employee: " + emp));

		entity.getTransaction().commit();
	}
}
