package com.demo;

import java.util.List;
import java.util.concurrent.Delayed;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Client {
public static void main(String[] args) {
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("jpql");
	EntityManager entity=factory.createEntityManager();
	
	entity.getTransaction().begin();
	
	Employee e= new Employee(123, "karthik", 9338, "ohio");
	Employee e1= new Employee(124, "rahul", 7633, "dallas");
	Employee e2= new Employee(125, "keerthi", 8263, "kochi");
	Employee e3= new Employee(127, "sathya", 1836, "hyd");
	Employee e4= new Employee(1239, "mahesh", 5498, "bnglr");
	
	
//	entity.persist(e);
//	entity.persist(e1);
//	entity.persist(e2);
//	entity.persist(e3);
//	entity.persist(e4);
	
	
	//fetching all the data from database 
	Query q=entity.createQuery("SELECT e FROM Employee e");
	List<Employee> li=q.getResultList();
	
	for(Employee fetchdata:li)
	{
		System.out.println("Employee Id :"+fetchdata.getEmpid());
		System.out.println("\t Employee Name :"+fetchdata.getEmpname());
		System.out.println("\t Employee Salary :"+fetchdata.getEmpsal());
		System.out.println("\t Employee Address :"+fetchdata.getEmpadd());
	
	}
	
	//printing all names in UPPERCASE
	
	Query q1=entity.createQuery("SELECT UPPER(e.empname) FROM Employee e");
	List<String> li1=q1.getResultList();
	for(String upcase:li1)
	{
		System.out.println("Employee Name :"+upcase);
	}
	
	//printing maximum salary from databse
	
	Query q2=entity.createQuery("SELECT MAX(e.empsal) FROM Employee e");
	int maxSal=(int) q2.getSingleResult();
	System.out.println("maximum salary is :"+maxSal);
	
	//finding salary BETWEEN RANGE
	Query q3=entity.createQuery("SELECT e From Employee e WHERE e.empsal BETWEEN 2000 and 9000");
	List<Employee> li2=q3.getResultList();
	for(Employee range:li2)
	{
		System.out.println("Employee id :"+range.getEmpid());
		System.out.println("\t Employee salary  :"+range.getEmpsal());
	}
	
	//like starts with k
	
	Query q4=entity.createQuery("SELECT e FROM Employee e where e.empname Like 'k%'");
	List<Employee> li3=q4.getResultList();
	
	for(Employee letr:li3)
	{
		System.out.println("Employee id :"+letr.getEmpid());
		System.out.println("\t Employee Name :"+letr.getEmpname());
	}
	//updating salarys to insert extra 5000
	Query q5=entity.createQuery("update Employee set empsal=empsal+5000 where empsal<9000");
	int updatedData=q5.executeUpdate();
	System.out.println("updated Records :"+updatedData);
	
	//ordering the employess
	Query q6=entity.createQuery("SELECT e From Employee e Order by e.empname ASC");
	List<Employee> li5=q6.getResultList();
	for(Employee ordr:li5)
	{
		System.out.println("Employee id :"+ordr.getEmpid());
		System.out.println("\t Employee Name :"+ordr.getEmpname());
	}
	//deleteing data from databse
	Query q7=entity.createQuery("delete from Employee e where e.empsal<12000");
	int dletedrcrds=q7.executeUpdate();
	System.out.println("deleted :"+dletedrcrds);
	
	
	entity.getTransaction().commit();
}
}
