package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	 public static void main(String[] args) {
		
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("keerthi");
	        EntityManager em = emf.createEntityManager();

	        em.getTransaction().begin();

	        Employee employee1 = new Employee();
	        employee1.setName("Alice");
	        Employee employee2 = new Employee();
	        employee2.setName("Bob");

	        Department department = new Department();
	        department.getEmployees().add(employee1);
	        department.getEmployees().add(employee2);
	        em.persist(department);

	        em.getTransaction().commit();

	        Department fetchedDepartment = em.find(Department.class, department.getId());
	        System.out.println("Fetched Department with Employees: ");
	        fetchedDepartment.getEmployees().forEach(emp -> System.out.println(emp.getName()));

	        em.close();
	        emf.close();
		    }
}
