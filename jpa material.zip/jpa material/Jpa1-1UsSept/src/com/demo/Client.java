package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("keerthi");
		EntityManager entity=factory.createEntityManager();
		entity.getTransaction().begin();
		
		Address add= new Address();
		add.setHunum(567);
		add.setColony("saraswathi nagar");
		add.setState("rr");
		add.setPincode(50074);
		
		Employee emp= new Employee();
		emp.setEmpid(100);
		emp.setEmpname("sathya");
		emp.setEmpsal(3000);
		emp.setAddress(add);
		
		//entity.persist(add);
		//entity.persist(emp);
		
		//fetching data from database
		
		Employee fetchEmp=entity.find(Employee.class, emp.getEmpid());
		System.out.println("Employee Id :"+fetchEmp.getEmpid());
		System.out.println("\t Employee Name :"+fetchEmp.getEmpname());
		System.out.println("\t Employee Salary :"+fetchEmp.getEmpsal());
		System.out.println("\t Employee Hunum :"+fetchEmp.getAddress().getHunum());
		System.out.println("\t Employee colony :"+fetchEmp.getAddress().getColony());
		System.out.println("\t Employee state :"+fetchEmp.getAddress().getState());
		System.out.println("\t Employee pincode :"+fetchEmp.getAddress().getPincode());
		
		//update
		Address add1= entity.find(Address.class, add.getHunum());
		add1.setColony("navodaya");
		add1.setPincode(90000);
		emp.setEmpname("keerthi");
		emp.setAddress(add1);
		
		
		//entity.merge(fetchEmp);
		entity.remove(fetchEmp);
		
		
		
		
		
		
		
		
		
		
		
		
		
		entity.getTransaction().commit();
		
	}
}
