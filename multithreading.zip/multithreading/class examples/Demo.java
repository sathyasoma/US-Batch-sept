package com.demo.multi;

public class Demo {

	public static void main(String[] args) { //main thread
		
		System.out.println("welcome to multi threading ocncept");
	}
}
